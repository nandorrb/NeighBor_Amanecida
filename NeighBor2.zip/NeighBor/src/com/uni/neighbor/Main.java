package com.uni.neighbor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Filter.FilterListener;
import android.widget.FilterQueryProvider;
import android.widget.ListView;
import android.widget.Toast;

import com.wenchao.jsql.JSQLite;

public class Main extends Activity {
	// TODO
	// Give preference to appear to products on offer
	// Impelement a Way to search the barcode Scanner

	ListView displayList;
	Context context;
	DBHelper dbHelper;
	String jsonData;
	SQLiteDatabase db;
	String contents;
	String feedUrl = "http://gdata.youtube.com/feeds/api/users/twistedequations/uploads?v=2&alt=jsonc&start-index=1&max-results=10";
	// String feedUrl;
	Cursor cursor;
	// test String JSON object
	String jsonString = "{ \"products\" :"
			+ "[{\"_id\":1,\"definition\":\"coca cola\",\"price\":2,\"brand\":\"The cocaCola company\",\"offer\":0.6},{\"_id\":2,\"definition\":\"inka cola\",\"price\":1,\"brand\":\"The cocaCola company\",\"offer\":0},{\"_id\":3,\"definition\":\"laptop\",\"price\":500,\"brand\":\"Toshiba\",\"offer\":0.7},{\"_id\":4,\"definition\":\"robot\",\"price\":800,\"brand\":\"Honda\",\"offer\":0}]"
			+ "}";
	ClientCursorAdapter adapter;
	Cursor oldCursor;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		savedata(jsonString);
		setContentView(R.layout.main);
		context = this;
		displayList = (ListView) findViewById(R.id.videoList);
		displayList.setFastScrollEnabled(true);
		displayList.setTextFilterEnabled(true);
		setAdapter();
		// To Download the DB
		// DownloadJson loaderTask = new DownloadJson();
		// loaderTask.execute();
		final EditText edt = (EditText) findViewById(R.id.SearchBar);
		edt.addTextChangedListener(new TextWatcher() {
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
			}

			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			public void afterTextChanged(Editable s) {
				ClientCursorAdapter filterAdapter = (ClientCursorAdapter) displayList
						.getAdapter();
				filterAdapter.getFilter().filter(s.toString());
			}
		});

		adapter.setFilterQueryProvider(new FilterQueryProvider() {
			public Cursor runQuery(CharSequence constraint) {
				return getDirectoryList(constraint);
			}

			public Cursor getDirectoryList(CharSequence constraint) {
				SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
				queryBuilder.setTables("products");

				String asColumnsToReturn[] = { "products" + "." + "_id" + ","
						+ "products" + "." + "definition" + "," + "products"
						+ "." + "price" + "," + "products" + "." + "brand"
						+ "," + "products" + "." + "offer" };

				if (constraint == null || constraint.length() == 0) {
					// Return the full list
					return queryBuilder.query(db, asColumnsToReturn, null,
							null, null, null, null);
				} else {
					String value = "%" + constraint.toString() + "%";

					return db.query("products", asColumnsToReturn,"definition like ? OR price like ?",new String[] { value, value }, null, null, null);
				}
			}
		});

	}

	private void setAdapter() {
		cursor = db.rawQuery("SELECT * FROM products", null); // cursor query
		adapter = new ClientCursorAdapter(this, R.layout.video_list_item,
				cursor, 0);
		// this.setListAdapter(adapter);
		displayList.setAdapter(adapter);
	}

	private void savedata(String resultData) {
		// TODO Auto-generated method stub
		// Preparing SQLite Database
		dbHelper = new DBHelper(this);
		db = dbHelper.getWritableDatabase();

		// db.execSQL("DROP TABLE IF EXISTS " + "PRODUCTS");
		// //initialize JSQLite Object

		JSQLite jsql;
		try {
			jsql = new JSQLite(resultData, db);
			// persist to database
			jsql.persist();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection
		switch (item.getItemId()) {
		case R.id.scann:
			try {
				scann();
				feedUrl = contents;
			} finally {
				contents = " ";
			}
			return true;
		case R.id.BarcodeSearch:
			try {
				// scann();

			} finally {

			}
			return true;
		case R.id.action_settings:
			// showHelp();
			return true;
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void scann() {
		// TODO Auto-generated method stub
		Intent intent = new Intent("com.google.zxing.client.android.SCAN");
		intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
		startActivityForResult(intent, 0);

	}

	public void onActivityResult(int requestCode, int resultCode, Intent intent) {
		if (requestCode == 0) {
			if (resultCode == RESULT_OK) {
				contents = intent.getStringExtra("SCAN_RESULT");
				feedUrl = contents;
				// Result format
				// String format = intent.getStringExtra("SCAN_RESULT_FORMAT");
				Log.i("Barcode Result", contents);

				// Handle successful scan
			} else if (resultCode == RESULT_CANCELED) {
				// Handle cancel
				Log.i("Barcode Result", "Result canceled");

			}
		}
	}

	

	public class DownloadJson extends AsyncTask<Void, Void, Void> {
		ProgressDialog dialog;

		@Override
		protected void onPreExecute() {
			dialog = new ProgressDialog(context);
			dialog.setTitle("Loading Videos");
			dialog.show();
			super.onPreExecute();
		}

		@Override
		protected Void doInBackground(Void... params) {
			HttpClient client = new DefaultHttpClient();
			HttpGet getRequest = new HttpGet(feedUrl);

			try {
				HttpResponse responce = client.execute(getRequest);
				StatusLine statusLine = responce.getStatusLine();
				int statusCode = statusLine.getStatusCode();

				if (statusCode != 200) {
					return null;
				}

				InputStream jsonStream = responce.getEntity().getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(jsonStream));
				StringBuilder builder = new StringBuilder();
				String line;
				while ((line = reader.readLine()) != null) {
					builder.append(line);
				}
				// jsonData is the JSON string
				jsonData = builder.toString();
				// Guarda la Información
				// JSONObject json = new JSONObject(jsonData);
				// JSONObject data = json.getJSONObject("data");
				// JSONArray items = data.getJSONArray("items");
				//
				// for (int i = 0; i < items.length(); i++) {
				// JSONObject video = items.getJSONObject(i);
				// videoArrayList.add(video.getString("title"));
				// }

			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			dialog.dismiss();
			// videoAdapter.notifyDataSetChanged();
			Toast.makeText(getApplicationContext(), jsonData, Toast.LENGTH_LONG)
					.show();
			super.onPostExecute(result);
		}
	}
}
